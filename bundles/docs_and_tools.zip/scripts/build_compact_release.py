#!/usr/bin/env python3
"""Build a compact, self-validating public release without discarding audit data."""

from __future__ import annotations

import argparse
import json
import shutil
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
MANIFEST = ROOT / "manifests" / "release_manifest.json"

# Directly readable files are the main audit entry points.  The remaining
# allowlisted material is packaged by review function and expands on demand.
CORE = {
    "README.md",
    "SECURITY_BOUNDARY.md",
    "CITATION.cff",
    "LICENSE-CODE",
    "LICENSE-DATA",
    "reproduce_tables.py",
    "docs/coding/codebook.md",
    "docs/coding/data_dictionary.md",
    "data/corpus/corpus.csv",
    "data/corpus/study_version_crosswalk.csv",
    "data/coding/current_study_level_coding_matrix_harmonized.csv",
    "data/coding/adjudicated_study_level_coding_matrix_199.csv",
    "data/adjudication/adjudication_log_199_all_fields.csv",
    "data/adjudication/claim_alignment_reconciled_199.csv",
    "data/synthesis/study_synthesis_199.csv",
    "data/derived/derived_summary_tables.json",
    "data/derived/empirical_reporting_completeness.csv",
    "references/references_final_multisource_new_studies_20260730.bib",
    "references/references_merged_manuscript.bib",
}

BUNDLES = {
    "bundles/docs_and_tools.zip": {
        "docs/protocol/FINAL_MULTISOURCE_SEARCH_AND_PRISMA_20260730.md",
        "docs/release/RELEASE_MANIFEST.md",
        "docs/review/ADJUDICATION_COMPLETION_20260812.md",
        "docs/review/ADJUDICATION_RULES_20260812.md",
        "manifests/release_manifest.json",
        "scripts/build_compact_release.py",
        "scripts/build_public_release.py",
        "scripts/finalize_199_adjudication.py",
        "scripts/validate_199_adjudication_form.py",
    },
    "bundles/search.zip": {
        "data/search/final_multisource_search_20260730_access_log.csv",
        "data/search/final_multisource_search_20260730_results.csv",
        "data/search/final_multisource_search_20260730_screening_audit.csv",
        "data/search/final_multisource_search_20260730_complete_screening.csv",
        "data/search/final_multisource_search_20260730_fulltext_assessment.csv",
        "data/search/final_multisource_search_20260730_prisma_counts.csv",
        "data/search/final_multisource_search_20260730_dedup_resolutions.csv",
        "data/search/final_multisource_search_20260730_all_coder_comparison.csv",
    },
    "bundles/corpus_and_coding.zip": {
        "data/corpus/reference_audit.csv",
        "data/coding/current_study_level_coding_matrix_harmonized_pre_final_multisource_20260730.csv",
        "data/coding/extended_synthesis_audit.csv",
    },
    "bundles/reliability_and_rereview.zip": {
        "data/adjudication/integrated_199_second_coder_comparison_20260730.csv",
        "data/adjudication/integrated_199_per_label_reliability_20260730.csv",
        "data/adjudication/integrated_199_reporting_audit_disagreement_review.csv",
        "data/adjudication/integrated_199_label_substitution_sensitivity_20260730.csv",
        "data/adjudication/third_party_rereview_oy_20260824.csv",
        "data/adjudication/third_party_rereview_decisions_20260824.csv",
        "data/adjudication/third_party_rereview_qc_20260824.csv",
        "data/adjudication/third_party_rereview_material_crosswalk_20260824.csv",
    },
    "bundles/synthesis.zip": {
        "data/synthesis/traditional_security_primitives_by_use_role.csv",
        "data/synthesis/public_trigger_replay_evidence_index.csv",
        "data/synthesis/public_alignment_evidence_index.csv",
        "data/synthesis/representative_system_mechanisms.csv",
        "data/synthesis/mechanism_cost_ablation_synthesis.csv",
        "data/synthesis/representative_reported_results.csv",
        "data/synthesis/product_ecosystem_snapshot.csv",
    },
}


def release_paths() -> set[str]:
    payload = json.loads(MANIFEST.read_text(encoding="utf-8-sig"))
    return set(payload["manuscript_artifact_paths"]) | set(payload["static_release_files"])


def copy_file(relative: str, output: Path) -> None:
    source = ROOT / relative
    destination = output / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path, help="new, empty compact-release directory")
    args = parser.parse_args()
    output = args.output.resolve()
    if output.exists():
        raise SystemExit(f"ERROR: output already exists: {output}")
    if output == ROOT or ROOT in output.parents:
        raise SystemExit("ERROR: output must be outside the source artifact")

    allowlisted = release_paths()
    bundled = set().union(*BUNDLES.values())
    if CORE | bundled != allowlisted:
        missing = sorted(allowlisted - CORE - bundled)
        extra = sorted((CORE | bundled) - allowlisted)
        raise SystemExit(f"ERROR: compact-release mapping mismatch; missing={missing}; extra={extra}")

    output.mkdir(parents=True)
    for relative in sorted(CORE):
        copy_file(relative, output)
    for archive, paths in BUNDLES.items():
        archive_path = output / archive
        archive_path.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(archive_path, "w", compression=zipfile.ZIP_DEFLATED) as handle:
            for relative in sorted(paths):
                handle.write(ROOT / relative, relative)

    compact_manifest = {
        "format": "compact-audit-release-v1",
        "description": "All files in bundles are preserved with their original relative paths and expand automatically during validation.",
        "core_files": sorted(CORE),
        "bundles": {archive: sorted(paths) for archive, paths in BUNDLES.items()},
    }
    (output / "compact_bundle_manifest.json").write_text(
        json.dumps(compact_manifest, indent=2) + "\n", encoding="utf-8"
    )
    print(f"COMPACT_RELEASE_FILES={sum(path.is_file() for path in output.rglob('*'))}")
    print(f"COMPACT_RELEASE_OUTPUT={output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
