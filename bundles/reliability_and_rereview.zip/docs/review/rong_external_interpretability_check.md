# Rong External Interpretability Check

## Scope

Rong Zhoujie (University of Chinese Academy of Sciences; agent-security research) independently reviewed a fixed random sample of 50 target-software studies selected with seed `20260821`. The check covered four operational-presence fields: reporting and audit, validation organization / evidence packaging, context aggregation / rule extraction, and external traceability. The released record-level file contains 200 field rows (50 studies x 4 fields).

CP209 was unresolved on all four fields because the source did not meet the access threshold. The field-level comparisons therefore use 49 comparable studies per field. `rong_label` records Rong's judgment; `reference_label` records the corresponding label in the preserved pre-adjudication harmonized matrix. The reference is an audit comparator, not a gold standard and not the final adjudicated matrix.

## Reproduction Metrics

| Field | N | TP | FP | FN | TN | Raw agreement | Cohen kappa | Gwet AC1 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| Reporting and audit | 49 | 11 | 14 | 13 | 11 | 0.449 | -0.102 | -0.102 |
| Validation organization / evidence packaging | 49 | 28 | 8 | 9 | 4 | 0.653 | 0.088 | 0.440 |
| Context aggregation / rule extraction | 49 | 41 | 3 | 2 | 3 | 0.898 | 0.489 | 0.873 |
| External traceability | 49 | 26 | 1 | 20 | 2 | 0.571 | 0.059 | 0.309 |

For the first three fields, a positive reference label is the corresponding lifecycle or capability label. For external traceability, any reference value other than `no external trace reported` is positive. `comparable=no` rows are excluded from the metrics.

The check diagnoses how readily the operational rules can be applied to the reviewed sources. It does not estimate full-corpus accuracy, replace the adjudicated matrix, or establish that either label set is true.

## Record-Level Data

The accompanying CSV is `data/adjudication/rong_external_interpretability_check_50.csv`. It preserves sample identity, source locator and excerpt, Rong's label, the reference label, binary comparison fields, and the unresolved/access status needed to reproduce the table above.
